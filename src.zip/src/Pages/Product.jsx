import React, { useContext } from 'react';
import { useParams } from 'react-router-dom';
import productList from '../Components/Assets/all_product';
import Breadcrum from '../Components/BreadCrums/Breadcrum';
import ProductDisplay from '../Components/ProductDisplay/ProductDisplay';
import DescriptionBox from '../Components/DescriptionBox/DescriptionBox';
import RelatedProducts from '../Components/RelatedProducts/RelatedProducts';

const Product = () => {
  const {productId} = useParams();
  const product = productList.find((e) => e.id === 1);
  return (
    <div>
      <Breadcrum product={product}/>
      <ProductDisplay product={product}/>
      <DescriptionBox/>
      <RelatedProducts/>
    </div>
  );
};

export default Product;
